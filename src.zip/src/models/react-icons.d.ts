import type { FC, SVGProps } from 'react'
declare module 'react-icons' {
  export type IconType = FC<SVGProps<SVGSVGElement>>
}
