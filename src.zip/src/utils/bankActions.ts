export const handleBankTransfer = (account: string) => {
  alert(`KakaoPay transfer initiated to account: ${account}`)
}
